const donasi = () => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          DONASI BRO?  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱❉ *DONASI YOK* ❉⊰━━✿
┃   
┣━⊱ *GOPAY*
┣⊱ 082158549899
┣━⊱ *GOPAY*
┣⊱ 085754863382
┣━⊱ *PULSA*
┣⊱ 082158549899
┃
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
